package Gui.com;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
//import javaMginfQueuex.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Arrays;
import java.util.Enumeration;

import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import mod.sim.*;
import javax.swing.JTextArea;
import javax.swing.JTextPane;


public class ModSimGui extends JFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private Enumeration<AbstractButton> buttons ;
    private Mm1 Mm1Queue  ;
    private Mmm MmmQueue  ;
    private Mg0 MginfQueue  ;
    private Mmmn MmmnQueue  ;
    private JTextField textField_12;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModSimGui frame = new ModSimGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModSimGui() {
		setBackground(Color.GRAY);
		getContentPane().setEnabled(false);
		getContentPane().setBackground(Color.GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 745, 538);
		getContentPane().setLayout(null);
				
				JButton btnNewButton = new JButton("Analyse");
				
				btnNewButton.setBounds(335, 201, 103, 36);
				getContentPane().add(btnNewButton);
				
					btnNewButton.setForeground(new Color(255, 255, 255));
					btnNewButton.setFont(new Font("Ubuntu Condensed", Font.BOLD, 22));
					btnNewButton.setBackground(Color.DARK_GRAY);
					
					JPanel panel = new JPanel();
					panel.setForeground(new Color(51, 51, 51));
					panel.setBackground(Color.DARK_GRAY);
					panel.setBounds(12, 250, 721, 239);
					getContentPane().add(panel);
					panel.setLayout(null);
					
					JLabel lblNewLabel_2 = new JLabel("Les statistique");
					lblNewLabel_2.setForeground(Color.WHITE);
					lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 20));
					lblNewLabel_2.setBounds(287, 0, 182, 45);
					panel.add(lblNewLabel_2);
					
					textField_4 = new JTextField();
					textField_4.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_4.setForeground(Color.BLACK);
					textField_4.setBackground(Color.WHITE);
					textField_4.setEnabled(false);
					textField_4.setBounds(400, 60, 175, 19);
					panel.add(textField_4);
					textField_4.setColumns(10);
					
					JLabel lblNewLabel_4 = new JLabel("Server utilization (ρ):");
					lblNewLabel_4.setForeground(Color.WHITE);
					lblNewLabel_4.setBounds(53, 62, 200, 15);
					panel.add(lblNewLabel_4);
					
					JLabel lblNewLabel_4_1 = new JLabel("Effective Server utilization (ρeff):");
					lblNewLabel_4_1.setForeground(Color.WHITE);
					lblNewLabel_4_1.setBounds(53, 89, 250, 15);
					panel.add(lblNewLabel_4_1);
					
					JLabel lblNewLabel_4_2 = new JLabel("Mean number of customers in the system (Ls):");
					lblNewLabel_4_2.setForeground(Color.WHITE);
					lblNewLabel_4_2.setBounds(53, 116, 350, 15);
					panel.add(lblNewLabel_4_2);
					
					JLabel lblNewLabel_4_3 = new JLabel("Mean number of customers in the queue (Lq):");
					lblNewLabel_4_3.setForeground(Color.WHITE);
					lblNewLabel_4_3.setBounds(53, 143, 350, 15);
					panel.add(lblNewLabel_4_3);
					
					JLabel lblNewLabel_4_4 = new JLabel("Mean number of customers in service (Reff):");
					lblNewLabel_4_4.setForeground(Color.WHITE);
					lblNewLabel_4_4.setBounds(53, 192, 350, 15);
					panel.add(lblNewLabel_4_4);
					
					JLabel lblNewLabel_4_5 = new JLabel("Mean time spent in the system (Ws):");
					lblNewLabel_4_5.setForeground(Color.WHITE);
					lblNewLabel_4_5.setBounds(53, 167, 350, 15);
					panel.add(lblNewLabel_4_5);
					
					JLabel lblNewLabel_4_6 = new JLabel("Mean waiting time (spent in the queue) (Wq):");
					lblNewLabel_4_6.setForeground(Color.WHITE);
					lblNewLabel_4_6.setBounds(53, 216, 350, 15);
					panel.add(lblNewLabel_4_6);
					
					JLabel lblNewLabel_4_7 = new JLabel("Queue stability:");
					lblNewLabel_4_7.setForeground(Color.WHITE);
					lblNewLabel_4_7.setBounds(53, 30, 123, 15);
					panel.add(lblNewLabel_4_7);
					
					JLabel lblNewLabel_4_8 = new JLabel("Pi values:");
					lblNewLabel_4_8.setForeground(Color.WHITE);
					lblNewLabel_4_8.setBounds(611, 62, 135, 15);
					panel.add(lblNewLabel_4_8);
					
					textField_5 = new JTextField();
					textField_5.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_5.setForeground(Color.BLACK);
					textField_5.setBackground(Color.WHITE);
					textField_5.setEnabled(false);
					textField_5.setColumns(10);
					textField_5.setBounds(400, 85, 175, 19);
					panel.add(textField_5);
					
					textField_6 = new JTextField();
					textField_6.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_6.setForeground(Color.BLACK);
					textField_6.setBackground(Color.WHITE);
					textField_6.setEnabled(false);
					textField_6.setColumns(10);
					textField_6.setBounds(400, 110, 175, 19);
					panel.add(textField_6);
					
					textField_7 = new JTextField();
					textField_7.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_7.setForeground(Color.BLACK);
					textField_7.setBackground(Color.WHITE);
					textField_7.setEnabled(false);
					textField_7.setColumns(10);
					textField_7.setBounds(400, 135, 175, 19);
					panel.add(textField_7);
					
					textField_8 = new JTextField();
					textField_8.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_8.setForeground(Color.BLACK);
					textField_8.setBackground(Color.WHITE);
					textField_8.setEnabled(false);
					textField_8.setColumns(10);
					textField_8.setBounds(400, 160, 175, 19);
					panel.add(textField_8);
					
					textField_9 = new JTextField();
					textField_9.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_9.setForeground(Color.BLACK);
					textField_9.setBackground(Color.WHITE);
					textField_9.setEnabled(false);
					textField_9.setColumns(10);
					textField_9.setBounds(400, 185, 175, 19);
					panel.add(textField_9);
					
					textField_10 = new JTextField();
					textField_10.setFont(new Font("Dialog", Font.BOLD, 14));
					textField_10.setForeground(Color.BLACK);
					textField_10.setBackground(Color.WHITE);
					textField_10.setEnabled(false);
					textField_10.setColumns(10);
					textField_10.setBounds(400, 210, 175, 19);
					panel.add(textField_10);
					
					JTextPane textPane = new JTextPane();
					textPane.setBackground(new Color(255, 255, 255));
					textPane.setBounds(581, 89, 128, 117);
					panel.add(textPane);
					
					JPanel panel_2 = new JPanel();
					panel_2.setBackground(Color.DARK_GRAY);
					panel_2.setBounds(12, 0, 359, 189);
					getContentPane().add(panel_2);
					panel_2.setLayout(null);
					
					JLabel lblNewLabel = new JLabel("Type de file d'attente");
					lblNewLabel.setForeground(Color.WHITE);
					lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
					lblNewLabel.setBounds(48, 22, 260, 24);
					panel_2.add(lblNewLabel);
					ButtonGroup G1 = new ButtonGroup();
					JRadioButton rdbtnNewRadioButton = new JRadioButton("Mm1");
					rdbtnNewRadioButton.setFont(new Font("Ubuntu Light", Font.BOLD, 16));
					rdbtnNewRadioButton.setForeground(Color.WHITE);
					rdbtnNewRadioButton.setBackground(Color.DARK_GRAY);
					rdbtnNewRadioButton.setBounds(69, 72, 186, 23);
					panel_2.add(rdbtnNewRadioButton);
					
					JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Mmm");
					rdbtnNewRadioButton_1.setFont(new Font("Ubuntu Light", Font.BOLD, 16));
					rdbtnNewRadioButton_1.setForeground(Color.WHITE);
					rdbtnNewRadioButton_1.setBackground(Color.DARK_GRAY);
					rdbtnNewRadioButton_1.setBounds(69, 99, 186, 23);
					panel_2.add(rdbtnNewRadioButton_1);
					
					JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Mginf");
					rdbtnNewRadioButton_2.setFont(new Font("Ubuntu Light", Font.BOLD, 16));
					rdbtnNewRadioButton_2.setForeground(Color.WHITE);
					rdbtnNewRadioButton_2.setBackground(Color.DARK_GRAY);
					rdbtnNewRadioButton_2.setBounds(69, 126, 186, 23);
					panel_2.add(rdbtnNewRadioButton_2);
					
					JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("Mmmn");
					rdbtnNewRadioButton_3.setFont(new Font("Ubuntu Light", Font.BOLD, 16));
					rdbtnNewRadioButton_3.setForeground(Color.WHITE);
					rdbtnNewRadioButton_3.setBackground(Color.DARK_GRAY);
					rdbtnNewRadioButton_3.setBounds(69, 153, 186, 23);
					panel_2.add(rdbtnNewRadioButton_3);
					G1.add(rdbtnNewRadioButton);
					G1.add(rdbtnNewRadioButton_1);
					G1.add(rdbtnNewRadioButton_2);
					G1.add(rdbtnNewRadioButton_3);
					JPanel panel_2_1 = new JPanel();
					panel_2_1.setBackground(Color.DARK_GRAY);
					panel_2_1.setBounds(383, 0, 350, 189);
					getContentPane().add(panel_2_1);
					panel_2_1.setLayout(null);
					
					JLabel lblNewLabel_1 = new JLabel("User Input");
					lblNewLabel_1.setForeground(Color.WHITE);
					lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 20));
					lblNewLabel_1.setBounds(108, 25, 135, 24);
					panel_2_1.add(lblNewLabel_1);
					
					JLabel lblNewLabel_3 = new JLabel("Arrival Rate (λ):");
					lblNewLabel_3.setForeground(Color.WHITE);
					lblNewLabel_3.setBounds(36, 60, 126, 15);
					panel_2_1.add(lblNewLabel_3);
					
					JLabel lblNewLabel_3_1 = new JLabel("Service Rate (μ):");
					lblNewLabel_3_1.setForeground(Color.WHITE);
					lblNewLabel_3_1.setBounds(36, 80, 126, 15);
					panel_2_1.add(lblNewLabel_3_1);
					
					JLabel lblNewLabel_3_2 = new JLabel("Number of servers:");
					lblNewLabel_3_2.setForeground(Color.WHITE);
					lblNewLabel_3_2.setBounds(36, 100, 150, 15);
					panel_2_1.add(lblNewLabel_3_2);
					
					JLabel lblNewLabel_3_3 = new JLabel("Queue capacity:");
					lblNewLabel_3_3.setForeground(Color.WHITE);
					lblNewLabel_3_3.setBounds(36, 120, 126, 15);
					panel_2_1.add(lblNewLabel_3_3);
					
					JLabel lblNewLabel_3_4 = new JLabel("Probabilities Pi:");
					lblNewLabel_3_4.setForeground(Color.WHITE);
					lblNewLabel_3_4.setBounds(36, 140, 126, 15);
					panel_2_1.add(lblNewLabel_3_4);
					
					textField = new JTextField();
					textField.setBounds(201, 59, 114, 19);
					textField.setText("2.47");
					panel_2_1.add(textField);
					textField.setColumns(10);
					
					textField_1 = new JTextField();
					textField_1.setBounds(201, 80, 114, 19);
					textField_1.setText("3.11");
					panel_2_1.add(textField_1);
					textField_1.setColumns(10);
					
					textField_2 = new JTextField();
					textField_2.setBounds(201, 100, 114, 19);
					textField_2.setText("1");
					panel_2_1.add(textField_2);
					textField_2.setColumns(10);
					
					textField_3 = new JTextField();
					textField_3.setBounds(201, 120, 114, 19);
					textField_3.setText("0");
					panel_2_1.add(textField_3);
					textField_3.setColumns(10);
					
					textField_12 = new JTextField();
					textField_12.setText("0");
					textField_12.setColumns(10);
					textField_12.setBounds(201, 140, 114, 19);
					panel_2_1.add(textField_12);
					
					btnNewButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							for (buttons = G1.getElements();buttons.hasMoreElements() ;) {
								AbstractButton button = buttons.nextElement();
								if(button.getText()=="Mmmn" && button.isSelected()) {
									MmmnQueue = new Mmmn( Double.parseDouble(textField.getText()),Double.parseDouble(textField_1.getText()),Integer.parseInt(textField_2.getText()),Integer.parseInt(textField_3.getText()));
									lblNewLabel_4_7.setText("Queue always stable");
									textField_4.setText(Double.toString((float)MmmnQueue.getRoh()));
									textField_5.setText(Double.toString((float)MmmnQueue.getRohEff()));
									textField_6.setText(Double.toString((float)MmmnQueue.getMoy_N_()));
									textField_7.setText(Double.toString((float)MmmnQueue.getMoy_Q_()));
									textField_8.setText(Double.toString((float)MmmnQueue.getMoy_R_()));
									textField_9.setText(Double.toString((float)MmmnQueue.getMoy_T_()));
									textField_10.setText(Double.toString((float)MmmnQueue.getMoy_W_()));
									MmmnQueue.calculate_Pn(Integer.parseInt(textField_12.getText()));
									String pn = ""; int i=0 ;
									for(Double ele: MmmnQueue.getPn()) {
										pn += "p ( "+ i++ +" ) = "+ Double.toString(ele.floatValue())+"\n" ; 
										
									}
									System.out.println("fouzi".substring(0,2));
									textPane.setText(pn);
									
								}else if(button.getText()=="Mm1" && button.isSelected()) {
									Mm1Queue = new Mm1( Double.parseDouble(textField.getText()),Double.parseDouble(textField_1.getText()));
									if (Mm1Queue.isStable()) {
										lblNewLabel_4_7.setText("Queue stable");	
									}else {
										lblNewLabel_4_7.setText("Queue is not stable");
									}
									
									textField_4.setText(Double.toString((float)Mm1Queue.getRoh()));
									
									textField_6.setText(Double.toString((float)Mm1Queue.getMoy_N_()));
									textField_7.setText(Double.toString((float)Mm1Queue.getMoy_Q_()));
									textField_8.setText(Double.toString((float)Mm1Queue.getMoy_R_()));
									textField_9.setText(Double.toString((float)Mm1Queue.getMoy_T_()));
									textField_10.setText(Double.toString((float)Mm1Queue.getMoy_W_()));
									Mm1Queue.calculate_Pn(Integer.parseInt(textField_12.getText()));
									String pn = ""; int i=0 ;
									for(Double ele: Mm1Queue.getPn()) {
										
										pn += "p ( "+ i++ +" ) = "+ Double.toString(ele.floatValue())+"\n" ; 
										
									}
									textPane.setText(pn);
								
								}else if(button.getText()=="Mginf" && button.isSelected()) {
									MginfQueue = new Mg0( Double.parseDouble(textField.getText()),Double.parseDouble(textField_1.getText()));
									lblNewLabel_4_7.setText("Always stable");
									textField_4.setText(Double.toString((float)MginfQueue.getRoh()));
									textField_6.setText(Double.toString((float)MginfQueue.getMoy_N_()));
									textField_7.setText(Double.toString((float)MginfQueue.getMoy_Q_()));
									textField_8.setText(Double.toString((float)MginfQueue.getMoy_R_()));
									textField_9.setText(Double.toString((float)MginfQueue.getMoy_T_()));
									textField_10.setText(Double.toString((float)MginfQueue.getMoy_W_()));
									MginfQueue.calculate_Pn(Integer.parseInt(textField_12.getText()));
									String pn = ""; int i=0 ;
									for(Double ele: MginfQueue.getPn()) {
										
										pn += "p ( "+ i++ +" ) = "+ Double.toString(ele.floatValue())+"\n" ; 
										
									}
									textPane.setText(pn);
								}else if(button.getText()=="Mmm" && button.isSelected()) {
									MmmQueue = new Mmm( Double.parseDouble(textField.getText()),Double.parseDouble(textField_1.getText()),Integer.parseInt(textField_2.getText()));
									if (MmmQueue.isStable()) {
										lblNewLabel_4_7.setText("Queue stable");	
									}else {
										lblNewLabel_4_7.setText("Queue is not stable");
									}
									textField_4.setText(Double.toString((float)MmmQueue.getRoh()));
									textField_6.setText(Double.toString((float)MmmQueue.getMoy_N_()));
									textField_7.setText(Double.toString((float)MmmQueue.getMoy_Q_()));
									textField_8.setText(Double.toString((float)MmmQueue.getMoy_R_()));
									textField_9.setText(Double.toString((float)MmmQueue.getMoy_T_()));
									textField_10.setText(Double.toString((float)MmmQueue.getMoy_W_()));
									MmmQueue.calculate_Pn(Integer.parseInt(textField_12.getText()));
									String pn = ""; int i=0 ;
									for(Double ele: MmmQueue.getPn()) {
										
										pn += "p ( "+ i++ +" ) = "+ Double.toString(ele.floatValue())+"\n" ; 
										
									}
									textPane.setText(pn);
								}
							}		
						
						}
					});
					
					
	}
}
