package mod.sim;

import java.util.ArrayList;

public class Mg0 extends Queue {

	public Mg0(double lamda, double mui) {
		super(lamda, mui);
		this.setMoy_Q_(0);
		this.setMoy_W_(0);
		update();
	}

	@Override
	public void setLamda(double lamda) {
		super.setLamda(lamda);
		update();

	}

	@Override
	public void setMui(double mui) {
		super.setMui(mui);

		update();

	}

	private void calculate_P0() {
		this.setP0(Math.exp(-this.getLamda() / this.getMui()));
	}
	public static int fact(int n) {
		int f = 1;
		for (int i = 1; i <= n; i++) {
			f *= i;
		}
		return f;
	}
	public void calculate_Pn(int n) {

		ArrayList<Double> pn = new ArrayList<Double>();
		for (int i = 0; i <= n; i++) {
			double result = (Math.pow(   this.getLamda() / this.getMui(), i  )  *   Math.exp(  -this.getLamda() / this.getMui()  ))/fact(i);
			pn.add(result);
		}
		this.setPn(pn);

	}

	private void calculat_Moy_N() {
		this.setMoy_N_(this.getLamda() / this.getMui());
	}
	
	private void calculat_Moy_R(){
		this.setMoy_R_(this.getMoy_N_());
	}

	private void calculat_Moy_T() {
		setMoy_T_(1 / this.getMui());
	}

	private void update() {
		calculat_Moy_N();
		calculat_Moy_R();
		calculat_Moy_T();
		calculate_P0();
		calculate_Pn(0);

	}

	public void Mm1_print() {
		System.out.println("\n" + "#".repeat(40) + "\n");

		System.out.println(" lamda = " + this.getLamda());
		System.out.println(" mui = " + this.getMui());
		System.out.println(" p0 = " + this.getP0());
		System.out.println(" Moy_N_ = " + this.getMoy_N_());
		System.out.println(" Moy_Q_ = " + this.getMoy_Q_());
		System.out.println(" Moy_N_ = " + this.getMoy_R_());
		System.out.println(" Moy_T_ = " + this.getMoy_T_());
		System.out.println(" Moy_W_ = " + this.getMoy_W_());
		System.out.println("\n" + "#".repeat(40) + "\n");
	}
     public static void main(String[] args) {
     Mg0 queue = new Mg0(2.47, 3.11 );
 		queue.Mm1_print();
 		
         queue.calculate_Pn(10);
         int i = 0 ; 
         for (Double ele : queue.getPn()) {
 			System.out.println("p ["+ i++ +"] = "+ele);
 		}
     }
}
