package mod.sim;

import java.util.ArrayList;

public class Mmm extends Queue {
	
	private int m; // serverNumber ;
    private double c ; //probability of waiting
  
	public Mmm(double lamda, double mui, int m) {
		super(lamda, mui);
 		this.m = m ;
		if (isStable()) {
			update();
		}
	}

	@Override
	public void setLamda(double lamda) {
		super.setLamda(lamda);
		if (isStable()) {
			update();
		}
	}

	@Override
	public void setMui(double mui) {
		super.setMui(mui);
		if (isStable()) {
			update();
		}
	}

	public boolean isStable() {
		if (this.getLamda() / (m * this.getMui()) < 1.0) {
			return true;
		} else {
			return false;
		}
	}

	private void calculate_roh() {
		this.setRoh(this.getLamda() / (m * this.getMui()));
	}

	public static int fact(int n) {
		int f = 1;
		for (int i = 1; i <= n; i++) {
			f *= i;
		}
		return f;
	}

	public static double some(double m, double roh) {
		double s = 0.0;
		for (int i = 0; i <= m - 1; i++) {
			s += Math.pow(m * roh, i) / fact(i);
		}
		return s;
	}

	private void calculate_P0() {
		this.setP0(1/((Math.pow(this.m * this.getRoh(), this.m)) / (fact(this.m) * (1 - this.getRoh()))
				+ some(this.m, this.getRoh())));
	}

	public void calculate_Pn(int n) {
		ArrayList<Double> pn = new ArrayList<Double>();
		for (int i = 0; i <= n; i++) {
			double result ;
			if(i<=this.m) {
				result = (Math.pow(this.m*this.getRoh(), i)/fact(i))*this.getP0();
			}else {
				result = (Math.pow(this.m*this.getRoh(), i)/(fact(this.m)*Math.pow(this.m, i-this.m)))*this.getP0();
			}
			pn.add(result);
		}
		this.setPn(pn);
	}


	private void calculat_Moy_Q() {
		this.setMoy_Q_((this.c*this.getRoh()) / (1 - this.getRoh()));
	}

	private void calculat_Moy_R() {
		this.setMoy_R_(this.m*this.getRoh());
	}
	

	private void calculat_Moy_N() {
	this.setMoy_N_(this.getMoy_Q_() + this.getMoy_R_());
	}

	private void calculat_Moy_T() {
		this.setMoy_T_(getMoy_N_() / this.getLamda());
	}

	private void calculat_Moy_W() {
		this.setMoy_W_(this.getMoy_Q_() / this.getLamda());
	}

	private void update() {
		isStable();
		calculate_roh();
		calculate_P0();
		this.c = (Math.pow(this.m*this.getRoh(), this.m)/(fact(this.m)*(1-this.getRoh())))*this.getP0();
		calculat_Moy_Q();
		calculat_Moy_R();
		calculat_Moy_N();
		calculat_Moy_T();
		calculat_Moy_W();
		calculate_Pn(0);

	}

	public void Mm1_print() {
		System.out.println("\n" + "#".repeat(40) + "\n");
		if (isStable()) {
			System.out.println(" lamda = " + this.getLamda());
			System.out.println(" mui = " + this.getMui());
			System.out.println(" m = " + this.m);
			System.out.println(" roh = " + this.getRoh());
			System.out.println(" p0 = " + this.getP0());
			System.out.println(" Moy_Q_ = " + this.getMoy_Q_());
			System.out.println(" Moy_R_ = " + this.getMoy_R_());
			System.out.println(" Moy_N_ = " + this.getMoy_N_());
			System.out.println(" Moy_T_ = " + this.getMoy_T_());
			System.out.println(" Moy_W_ = " + this.getMoy_W_());

		} else {
			System.out.println(" System is not stable , Lamda must be less then Mui see :  ");
			System.out.println(" lamda = " + getLamda());
			System.out.println(" mui = " + getMui());
		}
		System.out.println("\n" + "#".repeat(40) + "\n");
	}

	public static void main(String[] args) {
		Mmm queue = new Mmm(2.47, 3.11 , 2);
		queue.Mm1_print();
		
        queue.calculate_Pn(10);
        int i = 0 ; 
        for (Double ele : queue.getPn()) {
			System.out.println("p ["+ i++ +"] = "+ele);
		}
	}

}
