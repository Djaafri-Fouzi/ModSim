package mod.sim;

import java.util.ArrayList;


public class Mmmn extends Queue{
    private double lamdaE ; 
    private double RohEff ; 
    private int m ;
    private int n ;
	public Mmmn(double lamda, double mui , int m ,int n) {
		super(lamda, mui);
		this.m= m;
		this.n= n;
		update();
	}

	@Override
	public void setLamda(double lamda) {
		super.setLamda(lamda);
		
			update();
		
	}

	@Override
	public void setMui(double mui) {
		super.setMui(mui);
	        
			update();
		
	}
    
    public void setLamdaE(double lamdaE) {
		this.lamdaE = lamdaE;
	}
     public double getLamdaE() {
		return lamdaE;
	}
     public double getRohEff() {
		return RohEff;
	}
  
    private void calculate_lamadaE() {
    	calculate_Pn(n);
    	this.lamdaE = this.getLamda()*(1-this.getPn().get(this.getPn().size() - 1));
    } 
	private void calculate_roh() {
		this.setRoh(this.getLamda() / (m * this.getMui()));
	}
    private void calculate_getRohEff() {
    	this.RohEff = this.getLamdaE()/(this.getMui()*m);
    }
	public static int fact(int n) {
		int f = 1;
		for (int i = 1; i <= n; i++) {
			f *= i;
		}
		return f;
	}

	public static double some(double m, double roh  ) {
		double s = 0.0;
		for (int i = 0; i <= m - 1; i++) {
			s += Math.pow(m * roh, i) / fact(i);
		}
		return s;
	}

	private void calculate_P0() {
		if(this.getRoh() != 1){
		this.setP0(1/((Math.pow(m*this.getRoh(), m)/fact(m))*((1 - Math.pow(this.getRoh(), n-m+1))/(1 - this.getRoh()))+some(m, this.getRoh())) )  ;               
				
		}else{
			this.setP0(1/((n-m+1)*Math.pow(m*this.getRoh()*m, m)) / (fact(this.m) )+some(m, this.getRoh()))   ;               
					
		}
	} 

	public void calculate_Pn(int n) {
		ArrayList<Double> pn = new ArrayList<Double>();
		for (int i = 0; i <= n; i++) {
			double result ;
			if(i<=this.m) {
				result = (Math.pow(this.m*this.getRoh(), i)/fact(i))*this.getP0();
			}else if(i<=n) {
				result = ((Math.pow(m, m)*Math.pow(this.getRoh(), n))/fact(m))*this.getP0();
			}else {
				result = 0 ;
			}
			pn.add(result);
		}
		this.setPn(pn);
	}


	private void calculat_Moy_Q() {
		if(this.getRoh() != 1) {
			this.setMoy_Q_(((Math.pow(m*this.getRoh(), m)*this.getRoh()*this.getP0())/(fact(m)*Math.pow(1 - this.getRoh(),2 )))*(1- Math.pow(this.getRoh(),n-m )-(n-m)*(1-this.getRoh())*Math.pow(this.getRoh(),n-m )));	
		}else {
			this.setMoy_Q_((Math.pow(m, m)*(n-m)*(n-m+1)*this.getP0())/2*fact(m));
		}
		
	}

	private void calculat_Moy_R() {
		this.setMoy_R_(this.m*this.getRoh());
	}
	
	private void calculat_Moy_W() {
		setMoy_W_(this.getMoy_Q_() / this.getLamdaE());
	}
	
	private void calculat_Moy_T() {
		setMoy_T_(this.getMoy_W_() + 1/ this.getMui());
	}
	
	private void calculat_Moy_N() {
		this.setMoy_N_(this.getMoy_T_()*this.lamdaE);
    }

	

	private void update() {
		
		calculate_roh();
		calculate_P0();
		calculate_lamadaE();
		calculate_getRohEff();
		calculat_Moy_Q();
		calculat_Moy_W();
		calculat_Moy_T();
		calculat_Moy_N();
		calculat_Moy_R();
		calculate_Pn(0);

	}

	public void Mm1_print() {
		System.out.println("\n" + "#".repeat(40) + "\n");
		
			System.out.println(" lamda = " + this.getLamda());
			System.out.println(" mui = " + this.getMui());
			System.out.println(" roh = " + this.getRoh());
			System.out.println(" p0 = " + this.getP0());
			System.out.println(" Moy_N_ = " + this.getMoy_N_());
			System.out.println(" Moy_Q_ = " + this.getMoy_Q_());
			System.out.println(" Moy_R_ = " + this.getMoy_R_());
			System.out.println(" Moy_T_ = " + this.getMoy_T_());
			System.out.println(" Moy_W_ = " + this.getMoy_W_());
		
		System.out.println("\n" + "#".repeat(40) + "\n");
	}
	
	
	public static void main(String[] args) {
		Mmmn queue = new Mmmn(4.47,3.11,4,4);
		
        queue.Mm1_print();
        queue.calculate_Pn(5);
        for (Double ele : queue.getPn()) {
			System.out.println(ele);
		}
	}

}
