package mod.sim;
import java.util.ArrayList;
public class Queue {
	
     private double roh ; 
     
     private double mui ; 
     private double lamda ; 
     
     private double p0 ; 
     private  ArrayList<Double> pn = new ArrayList<Double>() ; 
     
     private double Moy_N_;
     private double Moy_Q_;
     private double Moy_R_;
    
     private double Moy_T_;
     private double Moy_W_;

     public Queue( double lamda , double mui ) {
 		this.lamda = lamda;
 		this.mui = mui ; 
 		 
 	}
     
    

	public double getRoh() {
		return roh;
	}



	public void setRoh(double roh) {
		this.roh = roh;
	}



	public double getLamda() {
		return lamda;
	}



	public void setLamda(double lamda) {
		this.lamda = lamda;
	}



	public double getP0() {
		return p0;
	}



	public void setP0(double p0) {
		this.p0 = p0;
	}



	public ArrayList<Double> getPn() {
		return pn;
	}



	public void setPn(ArrayList<Double> pn) {
		this.pn = pn;
	}



	public double getMoy_N_() {
		return Moy_N_;
	}



	public void setMoy_N_(double moy_N_) {
		Moy_N_ = moy_N_;
	}



	public double getMoy_Q_() {
		return Moy_Q_;
	}



	public void setMoy_Q_(double moy_Q_) {
		Moy_Q_ = moy_Q_;
	}



	public double getMoy_T_() {
		return Moy_T_;
	}



	public void setMoy_T_(double moy_T_) {
		Moy_T_ = moy_T_;
	}



	public double getMoy_W_() {
		return Moy_W_;
	}



	public void setMoy_W_(double moy_W_) {
		Moy_W_ = moy_W_;
	}



	public double getMui() {
		return mui;
	}



	public void setMui(double mui) {
		this.mui = mui;
	}
	
	
	
	public double getMoy_R_() {
		return Moy_R_;
	}
	public void setMoy_R_(double moy_R_) {
		Moy_R_ = moy_R_;
	}
	
	
	
}
	