/**
 * 
 */
/**
 * @author aymen
 *
 */
module ModSim {
	requires java.desktop;
}